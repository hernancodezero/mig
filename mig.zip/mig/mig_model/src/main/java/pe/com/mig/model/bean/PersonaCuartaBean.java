package pe.com.mig.model.bean;

import java.util.Date;

/**
 * @className: CierreMesBean.java
 * @description: 
 * @date: 16 de jun. de 2016
 * @author: SUMERIO.
 */
public class PersonaCuartaBean extends MBaseBean {

	private static final long serialVersionUID = 1L;
	private int srlIdPersonal;
	private int TConvenioCuarta;
	private int TDocumentoCuarta;
	private int TNacionalidad;
	private int TVia;
	private int TZona;
	private String numRuc;
	private String chrNumDocumento;
	private String chrApePaterno;
	private String chrApeMaterno;
	private String chrNombres;
	private String dteFecNacimiento;
	private String chrTipSexo;
	private String chrNumTelefono;
	private String chrCorreo;
	private String chrIndEssalud;
	private String chrIndDomiciliario;
	private String numRucConvenio;
	private String chrNomVia;
	private String chrNumHogar;
	private String chrNumInterior;
	private String chrNomZona;
	private String chrReferencia;
	private Integer idubigeo;
	private String chrCodUsuaCreacion;
	private Date dteFecCreacion;
	private String chrCodUsuaModifica;
	private Date dteFecModifica;
 
	/**
	 * @return the srlIdPersonal
	 */
	public int getSrlIdPersonal() {
		return srlIdPersonal;
	}
	/**
	 * @param srlIdPersonal the srlIdPersonal to set
	 */
	public void setSrlIdPersonal(int srlIdPersonal) {
		this.srlIdPersonal = srlIdPersonal;
	}
	/**
	 * @return the numRuc
	 */
	public String getNumRuc() {
		return numRuc;
	}
	/**
	 * @param numRuc the numRuc to set
	 */
	public void setNumRuc(String numRuc) {
		this.numRuc = numRuc;
	}
	/**
	 * @return the chrApePaterno
	 */
	public String getChrApePaterno() {
		return chrApePaterno;
	}
	/**
	 * @param chrApePaterno the chrApePaterno to set
	 */
	public void setChrApePaterno(String chrApePaterno) {
		this.chrApePaterno = chrApePaterno;
	}
	/**
	 * @return the chrApeMaterno
	 */
	public String getChrApeMaterno() {
		return chrApeMaterno;
	}
	/**
	 * @param chrApeMaterno the chrApeMaterno to set
	 */
	public void setChrApeMaterno(String chrApeMaterno) {
		this.chrApeMaterno = chrApeMaterno;
	}
	/**
	 * @return the chrNombres
	 */
	public String getChrNombres() {
		return chrNombres;
	}
	/**
	 * @param chrNombres the chrNombres to set
	 */
	public void setChrNombres(String chrNombres) {
		this.chrNombres = chrNombres;
	}
	 
	/**
	 * @return the dteFecNacimiento
	 */
	public String getDteFecNacimiento() {
		return dteFecNacimiento;
	}
	/**
	 * @param dteFecNacimiento the dteFecNacimiento to set
	 */
	public void setDteFecNacimiento(String dteFecNacimiento) {
		this.dteFecNacimiento = dteFecNacimiento;
	}
	/**
	 * @return the tConvenioCuarta
	 */
	public int getTConvenioCuarta() {
		return TConvenioCuarta;
	}
	/**
	 * @param tConvenioCuarta the tConvenioCuarta to set
	 */
	public void setTConvenioCuarta(int tConvenioCuarta) {
		TConvenioCuarta = tConvenioCuarta;
	}
	/**
	 * @return the tDocumentoCuarta
	 */
	public int getTDocumentoCuarta() {
		return TDocumentoCuarta;
	}
	/**
	 * @param tDocumentoCuarta the tDocumentoCuarta to set
	 */
	public void setTDocumentoCuarta(int tDocumentoCuarta) {
		TDocumentoCuarta = tDocumentoCuarta;
	}
	/**
	 * @return the tNacionalidad
	 */
	public int getTNacionalidad() {
		return TNacionalidad;
	}
	/**
	 * @param tNacionalidad the tNacionalidad to set
	 */
	public void setTNacionalidad(int tNacionalidad) {
		TNacionalidad = tNacionalidad;
	}
	/**
	 * @return the tVia
	 */
	public int getTVia() {
		return TVia;
	}
	/**
	 * @param tVia the tVia to set
	 */
	public void setTVia(int tVia) {
		TVia = tVia;
	}
	/**
	 * @return the tZona
	 */
	public int getTZona() {
		return TZona;
	}
	/**
	 * @param tZona the tZona to set
	 */
	public void setTZona(int tZona) {
		TZona = tZona;
	}
	/**
	 * @return the chrNumDocumento
	 */
	public String getChrNumDocumento() {
		return chrNumDocumento;
	}
	/**
	 * @param chrNumDocumento the chrNumDocumento to set
	 */
	public void setChrNumDocumento(String chrNumDocumento) {
		this.chrNumDocumento = chrNumDocumento;
	}
	/**
	 * @return the idubigeo
	 */
	public Integer getIdubigeo() {
		return idubigeo;
	}
	/**
	 * @param idubigeo the idubigeo to set
	 */
	public void setIdubigeo(Integer idubigeo) {
		this.idubigeo = idubigeo;
	}
	/**
	 * @return the chrCodUsuaCreacion
	 */
	public String getChrCodUsuaCreacion() {
		return chrCodUsuaCreacion;
	}
	/**
	 * @param chrCodUsuaCreacion the chrCodUsuaCreacion to set
	 */
	public void setChrCodUsuaCreacion(String chrCodUsuaCreacion) {
		this.chrCodUsuaCreacion = chrCodUsuaCreacion;
	}
	/**
	 * @return the dteFecCreacion
	 */
	public Date getDteFecCreacion() {
		return dteFecCreacion;
	}
	/**
	 * @param dteFecCreacion the dteFecCreacion to set
	 */
	public void setDteFecCreacion(Date dteFecCreacion) {
		this.dteFecCreacion = dteFecCreacion;
	}
	/**
	 * @return the chrCodUsuaModifica
	 */
	public String getChrCodUsuaModifica() {
		return chrCodUsuaModifica;
	}
	/**
	 * @param chrCodUsuaModifica the chrCodUsuaModifica to set
	 */
	public void setChrCodUsuaModifica(String chrCodUsuaModifica) {
		this.chrCodUsuaModifica = chrCodUsuaModifica;
	}
	/**
	 * @return the dteFecModifica
	 */
	public Date getDteFecModifica() {
		return dteFecModifica;
	}
	/**
	 * @param dteFecModifica the dteFecModifica to set
	 */
	public void setDteFecModifica(Date dteFecModifica) {
		this.dteFecModifica = dteFecModifica;
	}
 
	/**
	 * @return the chrTipSexo
	 */
	public String getChrTipSexo() {
		return chrTipSexo;
	}
	/**
	 * @param chrTipSexo the chrTipSexo to set
	 */
	public void setChrTipSexo(String chrTipSexo) {
		this.chrTipSexo = chrTipSexo;
	}
	/**
	 * @return the chrNumTelefono
	 */
	public String getChrNumTelefono() {
		return chrNumTelefono;
	}
	/**
	 * @param chrNumTelefono the chrNumTelefono to set
	 */
	public void setChrNumTelefono(String chrNumTelefono) {
		this.chrNumTelefono = chrNumTelefono;
	}
	/**
	 * @return the chrCorreo
	 */
	public String getChrCorreo() {
		return chrCorreo;
	}
	/**
	 * @param chrCorreo the chrCorreo to set
	 */
	public void setChrCorreo(String chrCorreo) {
		this.chrCorreo = chrCorreo;
	}
	/**
	 * @return the chrIndEssalud
	 */
	public String getChrIndEssalud() {
		return chrIndEssalud;
	}
	/**
	 * @param chrIndEssalud the chrIndEssalud to set
	 */
	public void setChrIndEssalud(String chrIndEssalud) {
		this.chrIndEssalud = chrIndEssalud;
	}
	/**
	 * @return the chrIndDomiciliario
	 */
	public String getChrIndDomiciliario() {
		return chrIndDomiciliario;
	}
	/**
	 * @param chrIndDomiciliario the chrIndDomiciliario to set
	 */
	public void setChrIndDomiciliario(String chrIndDomiciliario) {
		this.chrIndDomiciliario = chrIndDomiciliario;
	}
	/**
	 * @return the numRucConvenio
	 */
	public String getNumRucConvenio() {
		return numRucConvenio;
	}
	/**
	 * @param numRucConvenio the numRucConvenio to set
	 */
	public void setNumRucConvenio(String numRucConvenio) {
		this.numRucConvenio = numRucConvenio;
	}
	/**
	 * @return the chrNomVia
	 */
	public String getChrNomVia() {
		return chrNomVia;
	}
	/**
	 * @param chrNomVia the chrNomVia to set
	 */
	public void setChrNomVia(String chrNomVia) {
		this.chrNomVia = chrNomVia;
	}
	/**
	 * @return the chrNumHogar
	 */
	public String getChrNumHogar() {
		return chrNumHogar;
	}
	/**
	 * @param chrNumHogar the chrNumHogar to set
	 */
	public void setChrNumHogar(String chrNumHogar) {
		this.chrNumHogar = chrNumHogar;
	}
	/**
	 * @return the chrNumInterior
	 */
	public String getChrNumInterior() {
		return chrNumInterior;
	}
	/**
	 * @param chrNumInterior the chrNumInterior to set
	 */
	public void setChrNumInterior(String chrNumInterior) {
		this.chrNumInterior = chrNumInterior;
	}
	/**
	 * @return the chrNomZona
	 */
	public String getChrNomZona() {
		return chrNomZona;
	}
	/**
	 * @param chrNomZona the chrNomZona to set
	 */
	public void setChrNomZona(String chrNomZona) {
		this.chrNomZona = chrNomZona;
	}
	/**
	 * @return the chrReferencia
	 */
	public String getChrReferencia() {
		return chrReferencia;
	}
	/**
	 * @param chrReferencia the chrReferencia to set
	 */
	public void setChrReferencia(String chrReferencia) {
		this.chrReferencia = chrReferencia;
	}
	
}
